OverbyteIcsWebMwAppServer
=========================
Last update: Feb 18, 2011


OverbyteIcsWebMwAppServer is a demo for both MidWare and ICS. It implements a MidWare application server (port 2107) and a Web application server (port 20105).

Basically it is the ICS WebAppServer demo enhanced to be a MidWare application server and to use
an external MidWare application server (OverbyteSrvTst demo application server).

The schematic below shows the whole picture. We have 5 executables involved:
1) IEplorer: this is Internet Explorer which is used as a web client. Of course you may
   use your favorite browser instead.
2) OverbyteClientTest: This is a sample client program delivered with MidWare
3) OverbyteClientTest: A second copy of this program is used. Of course the same copy 
   could be used to access both application servers. Or you may use your own application.
4) OverbyteSrvTest: This is a sample server program delivered with MidWare. For the purpose
   of this demo, one TServerObject have been added: TServerObjectGETCLIENTLIKE2.
5) OverbyteIcsWebMwAppServer: This is a modified version of the sample server demo program
   delivered with ICS (OverbyteIcsWebAppServer). Three new TUrlHandler have been added for
   the demo: TUrlHandlerUpperCase, TUrlHandlerUpperCase2 and TUrlHandlerGetClientLike2.


                        OverbyteIcsWebMwAppServer.exe
                      +-----------------------------------------------------------------------------+
IExplorer.exe         |                                                                             |
+------------+        |  +--------------------+----------------+----------------+----------------+  |
|            |        |  |                    |                |                |                |  |
| Web Client |        |  |   Web App Server   |                |                |                |  |
|            +--------+  |        ICS         |  TUrlHandler   |  TUrlHandler   |  TUrlHandler   |  |
| (Browser)  |        |  |    THttpAppSrv     |  UpperCase     |  UpperCase2    | GetClientLike2 |  |
|            |        |  |    port 20105      |                |                |                |  |
+------------+        |  +--------------------+-------+--------+--------+-------+--------+-------+  |
                      |                               |                 |                |          |
                      |                               v                 v                v          |
                      |                       +----------------+----------------+----------------+  |
                      |                       |                |                |                |  |
                      |                       |    TMwClient   |  TAppSrvClient | TAppSrvClient  |  |
                      |                       |                |                |                |  |
                      |                       +----------------+----------------+----------------+  |
                      |                               |                 |                |          |
OverbyteClientTest.exe|                               v                 |                |          |
+------------+        |  +--------------------+----------------+        |                |          |
|            |        |  |                    |                |        |                |          |
|  MidWare   |        |  | MidWare App Server |                |        |                |          |
|  classic   +--------+  |         1          | TServerObject  |        |                |          |
|  Client1   |        |  |    TAppServer      | Upper          |        |                |          |
|            |        |  |    port 2107       |                |        |                |          |
+------------+        |  +--------------------+----------------+        |                |          |
                      |                                                 |                |          |
                      +-------------------------------------------------|----------------|----------+
                                                                        |                |
                                                                        |                |
                                                                        |                |
                                                                        |                |
                        OverbyteSrvTst.exe                              |                |
                      +-------------------------------------------------|----------------|----------+
OverbyteClientTest.exe|                                                 v                v          |
+------------+        |  +--------------------+----------------+----------------+----------------+  |
|            |        |  |                    |                |                |                |  |
|  MidWare   |        |  | MidWare App Server |                |                |                |  |
|  classic   +--------+  |         2          | TServerObject  | TServerObject  | TServerObject  |  |
|  Client2   |        |  |    TAppServer      | GetClientLike  | Upper          | GetClientLike2 |  |
|            |        |  |    port 2106       |                |                |                |  |
+------------+        |  +--------------------+----------------+----------------+----------------+  |
                      |                                                                             |
                      +-----------------------------------------------------------------------------+

There are a number of classes which are involved in this demo:
1) THttpAppSrv: This is the ICS component to build an web (http) application server.
2) TAppServer: This is the MidWare component to build a Midware application server.
3) TServerObjectUpper:
     This is a class implementing a function within a Midware application server.
     The function takes a single string parameter and produces a result set with
     the parameter converted to uppercase.
     Source in OverbyteSrvObj1.pas.
4) TUrlHandlerUppercase:
     This is a class implementing an URL within the web application server.
     This URL is simple, take a single parameter in query string named "value"
     and convert it to uppercase. The actual conversion is delegated to the
     class TServerObjectUpper within this application.
     The interesting part here is the use of TMwClient class which makes the
     glue between a TUrlHandler and a TServerObject. With TMwClient it is very
     easy to have the presentation done in a TUrlHandler (create HTML to render
     data in a web page) while getting the actual data is located in a
     TServerObject (Business rule).
     Source in OverbyteIcsWebAppServerUpperCase.pas
4) TUrlHandlerUpperCase2:
     This class expose the same functionnality as TUrlHandlerUppercase, but this 
     time the actual convertion is delegated to a TServerObject in another
     application server. This time, the glue between TUrlHandler and TServerObject
     in the MidWare component TAppSrvClient. In this scenario, the web app server
     is a simple client for an external Midware app server.
     Source in OverbyteIcsWebAppServerUpperCase2.pas. 
5) TServerObjectGetClientLike:
     This class expose the functionnality of querying a database for all records
     matching a given key (The SQL 'like' operator). The implementation is very 
     basic and does the minimum to do the requirements. This do not reflect what
     should be done in a real world application which require more robust code.
     However, this basic code emphasizes on Midware operation and clearly shows
     the simplicity of Midware inner working.
     Source in OverbyteSrvObj4.pas.
6) TServerObjectGetClientLike2:
     This class expose almost the same functionnalities as the basic class
     TServerObjectGetClientLike described above. It add a parameter to select
     the result set sort order. But the main difference is that this implementation
     really looks like a real world TServerObject with all features required.
     It makes use of metadata from client to server and back to client.
     It does parameter validation, uses parameterized SQL query and do error
     checking, returning meaningful messages to the client.
     TServerObjectGetClientLike2 is implemented using a two layer class: the
     actual class derive from an intermediate class which derive from TServerObject.
     This is how real world TServerObject should be designed: one or more
     intermediate classe having all the housekeeping methods common to an
     entire family of TServerObject. This design will minimize copying the
     same code everywhere. Any code generic enough for several TServerObject is
     moved to an intermediate class and reused by all derived classes.
     Source in OverbyteSrvObj12.pas. Intermediate class source is located
     in OverbyteSrvObj13.pas
7) TUrlHandlerGetClientLike2
     This class is the web presentation layer for TServerObjectGetClientLike2.
     Actually TServerObjectGetClientLike2 is called using TAppSrvClient because
     the instance is located in an external Midware application server, but
     TMwClient could have been used instead ot TAppSrvClient if the instance
     is located in the same application server. Using the correct glue class
     allows you to move a TServerObject from the same application server as
     the web part, or to an external application server. This is best of both
     world speaking about solution scalability.
     TUrlHandlerGetClientLike2 make use of metadata to send parameter to the
     server object and use metadata returned by server object to populate a
     html table having a header with the actual colum names decided at server
     side.
8) TAppSrvClient:
     This is the Midware class usually used at client side so that the client
     application is able to query an application server function implemented
     as a TServerObject.
     Here is is used within a TUrlHandler to query an application server 
     function implemented as a TServerObject in an external application server.
9) TMwClient:
     This is a "glue" class. It makes the link between a TUrlHandler and
     a TServerObject located in the same executable. TMwClient is used 
     instead of TAppSrvclient when the target TServerObject is located in the
     same executable.

--
Francois Piette
Http://www.overbyte.be
